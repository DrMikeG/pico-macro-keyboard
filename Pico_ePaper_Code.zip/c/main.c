﻿#include "EPD_Test.h"   //Examples

int main(void)
{
	// while(1) {
		
	    // DEV_Delay_ms(10000); 
	// }
	DEV_Delay_ms(500); 
	// EPD_2in9_V2_test();
    // EPD_2in9bc_test();
    // EPD_2in9b_V3_test();
    // EPD_2in9d_test();

    // EPD_2in13_V2_test();
	// EPD_2in13_V3_test();
    // EPD_2in13bc_test();
    // EPD_2in13b_V3_test();
    // EPD_2in13d_test();

    return 0;
}
